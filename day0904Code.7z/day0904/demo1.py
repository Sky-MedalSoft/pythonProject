from typing import Union


def func(data: Union[int, str]) -> int:
    return 10

def func2():
    pass
